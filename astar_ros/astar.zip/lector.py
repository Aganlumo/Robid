coordFile = "coordinates.txt"
try:
    with open(coordFile, 'r') as sxsy:
        sx = int(sxsy.readline())
        sy = int(sxsy.readline())

except IOError:
    sx = 190
    sy = 200
print(sx)
print(sy)
